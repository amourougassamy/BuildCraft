import assert from 'node:assert/strict'
import { baseline, validDesign } from '../lib/game/design'
import { calculate, cToF } from '../lib/game/engineering'
import { review } from '../lib/game/review'
import { thermal } from '../lib/game/assumptions'

const base=calculate(baseline)
assert.equal(base.footprint,2400)
assert.equal(base.gross,4800)
assert.equal(base.usable,3840)
assert.equal(base.capacityKW,56)
assert.equal(base.cost,956200)
assert.ok(validDesign(baseline))
assert.ok(!validDesign({...baseline,width:29}))
assert.ok(!validDesign({...baseline,ac:21}))
assert.ok(!validDesign({...baseline,braces:['front','front']}))
assert.ok(!validDesign({...baseline,use:'unknown'}))
const noAC=calculate({...baseline,ac:0})
const maxAC=calculate({...baseline,ac:20})
assert.ok(noAC.endF>cToF(thermal.initialC))
assert.ok(maxAC.endF>=cToF(thermal.thermostatC)-1e-9)
assert.ok(maxAC.endF<noAC.endF)
assert.equal(noAC.energyKWh,0)
assert.ok(maxAC.energyKWh>0)
assert.ok(calculate({...baseline,ac:0,insulation:'high'}).endF<calculate({...baseline,ac:0,insulation:'basic'}).endF)
assert.ok(calculate({...baseline,ac:0,use:'assembly'}).endF>calculate({...baseline,ac:0,use:'office'}).endF)
assert.ok(calculate({...baseline,floors:3}).gross>base.gross)
assert.ok(calculate({...baseline,ac:9}).cost>base.cost)
assert.ok(review(baseline).some(c=>c.category==='Code requirements' && c.status==='Not evaluated'))
assert.ok(review(baseline).some(c=>c.category==='Engineering performance' && c.status==='Not evaluated'))
assert.equal(base.points.length,13)
console.log('Model tests passed: bounds, area, cost, hot-day controls, thermostat, energy, and unevaluated checks.')
console.log(JSON.stringify({baseline: {cost:base.cost,endF:base.endF,energyKWh:base.energyKWh}, noAC:{endF:noAC.endF}, maxAC:{endF:maxAC.endF}},null,2))
